<?php

class Blog extends CI_Controller
{

        function Blog()
        {
            parent::__construct();
            $this->load->helper('url');
            $this->load->model('Categories');
            $this->load->model('Blogs');
        }

    
	function index()
	{
            $data['blogs'] = $this->Blogs->loadAll();
            $data['categories'] = $this->Categories->getCategoriesId();
            $this->load->view('blogView', $data);
	}
        
        function addNew()
        {
            $data['head'] = 'Jauns ieraksts';
            $data['name'] = '';
            $data['contents'] = '';
            $data['categories'] = $this->Categories->getCategories();
            $data['onSubmit'] = './savenew';
            $data['error'] = '';
            $data['selectedOption'] = 0;
            $this->load->view('editView',$data);
        }
        
        function edit($id)
        {
            $data['head'] = 'Ieraksta labošana';
            $data['name'] = $this->Blogs->getTitle($id);
            $data['contents'] = $this->Blogs->getContents($id);
            $data['categories'] = $this->Categories->getCategories();
            $data['error'] = '';
            $data['selectedOption'] = $this->Blogs->getCategory($id);
            $data['onSubmit'] = '../saveedit/' . $id;
            $this->load->view('editView',$data);
        }
        
        function savenew()
        {
            $values = array(
           'title' => mysql_real_escape_string($_POST['title']) ,
           'contents' => mysql_real_escape_string($_POST['contents']) ,
           'category_id' => mysql_real_escape_string($_POST['category'])
            );
            
            if ($values['category_id'] == 0) 
            {
                $data['head'] = 'Jauns ieraksts';
                $data['name'] = $values['title'];
                $data['contents'] = $values['contents'];
                $data['categories'] = $this->Categories->getCategories();
                $data['onSubmit'] = './savenew';
                $data['error'] = 'Nav norādīta kategorija';
                $data['selectedOption'] = $values['category_id'];
                $this->load->view('editView',$data);
                
            }
            else if ($values['title'] == '') 
            {
                $data['head'] = 'Jauns ieraksts';
                $data['name'] = $values['title'];
                $data['contents'] = $values['contents'];
                $data['categories'] = $this->Categories->getCategories();
                $data['onSubmit'] = './savenew';
                $data['error'] = 'Nav norādīts virsraksts';
                $data['selectedOption'] = $values['category_id'];
                $this->load->view('editView',$data);
            }
            
            else $this->Blogs->insertNew($values);
        }
        
        function saveEdit($id)
        {
            $values = array(
           'title' => mysql_real_escape_string($_POST['title']) ,
           'contents' => mysql_real_escape_string($_POST['contents']) ,
           'category_id' => mysql_real_escape_string($_POST['category'])
            );
            
            if ($values['category_id'] == 0) 
            {
                $data['head'] = 'Jauns ieraksts';
                $data['name'] = $values['title'];
                $data['contents'] = $values['contents'];
                $data['categories'] = $this->Categories->getCategories();
                $data['onSubmit'] = '../saveedit/' . $id;
                $data['error'] = 'Nav norādīta kategorija';
                $data['selectedOption'] = $values['category_id'];
                $this->load->view('editView',$data);
                
            }
            else if ($values['title'] == '') 
            {
                $data['head'] = 'Jauns ieraksts';
                $data['name'] = $values['title'];
                $data['contents'] = $values['contents'];
                $data['categories'] = $this->Categories->getCategories();
                $data['onSubmit'] = '../saveedit/' . $id;
                $data['error'] = 'Nav norādīts virsraksts';
                $data['selectedOption'] = $values['category_id'];
                $this->load->view('editView',$data);
            }
            
            else $this->Blogs->modifyPost($id,$values);
        }
}

?>
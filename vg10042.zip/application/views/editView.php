<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
	<h1><?php echo $head ?></h1>
        <p>
                <?php echo $error ?>
            </p>
	<form action=<?php echo $onSubmit ?> method="POST">
            
	    <fieldset>
		<p><label for="title">Nosaukums</label><br />
		    <input type="text" name="title" id="title" value="<?php echo ($name) ?>"/>
		</p>

		<p><label for="contents">Teksts</label><br />
		    <textarea name="contents" id="contents" cols="60" rows="8"  ><?php echo ($contents) ?></textarea>
		</p>

		<p><label for="category">Kategorija</label><br />
		    <select name="category" id="category">
                        <option value="0" <?php if ($selectedOption == 0) echo "selected='selected'" ?>>Izvēlies kategoriju</option>
                        <?php foreach($categories as $cat): ?>
                        <option value="<?php echo $cat['id']; ?>" <?php if ($selectedOption == $cat['id']) echo "selected='selected'" ?> ><?php echo $cat['title']; ?></option>
                        
                        <?php endforeach; ?>
                    </select>
		</p>
		<p><input type="submit" value="Saglabāt" /></p>

	    </fieldset>
	</form>

    </body>
</html>

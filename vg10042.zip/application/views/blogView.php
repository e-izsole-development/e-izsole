
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <title>
            Superblogs
        </title>
    </head>
    <body>
        <?php foreach($blogs as $row): ?>
        <h1><?php echo htmlspecialchars($row->title) ?></h1>  
        <p><?php echo htmlspecialchars($row->contents) ?></p>
        <p>Kategorija: <?php echo $categories[$row->category_id]; ?></p>
        <p><?php echo anchor('blog/edit/' . $row->id,'Labot'); ?></p>
        <?php endforeach ?>
        <p><?php echo anchor('blog/addnew/','Jauns ieraksts'); ?></p>
        
    </body>
</html>
